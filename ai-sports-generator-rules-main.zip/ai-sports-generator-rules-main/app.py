import streamlit as st
import os
import random
from dotenv import load_dotenv
from google import genai
from google.genai import types
from google.genai.errors import APIError

# -----------------------------------
# Load Environment Variables & State
# -----------------------------------
load_dotenv()

# Initialize session state for quiz and chat history
if "quiz_score" not in st.session_state:
    st.session_state.quiz_score = None
if "quiz_answers" not in st.session_state:
    st.session_state.quiz_answers = {}
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "quiz_questions" not in st.session_state:
    st.session_state.quiz_questions = []          # the active set of questions for this quiz attempt
if "quiz_started" not in st.session_state:
    st.session_state.quiz_started = False

# Candidate models list
CANDIDATE_MODELS = [
    "gemini-3.5-flash",
    "gemini-3.6-flash",
    "gemini-2.5-flash-lite"
]

SYSTEM_INSTRUCTION = """
You are "🏆 AI Sports Rules Assistant", a specialized AI companion designed to help users learn and understand rules of sports, sports terminologies, gameplay mechanisms, officiating, and general sports facts.

CRITICAL POLICY:
1. You MUST only answer questions related to sports rules, gameplay, sports terminologies, sports facts, or physical education rules.
2. If the user asks about any other topic (for example: coding, math, general science, non-sports history, general literature, writing code, cooking, general jokes, etc.), you MUST decline to answer politely but firmly. 
3. An example of a standard refusal: "I'm sorry, but I can only answer questions related to sports rules, terminology, and gameplay."
4. If the query is a simple greeting (like 'hi', 'hello', 'hey'), respond politely and mention that you are ready to help them with sports rules.
5. If the query is ambiguous, ask the user to clarify how it relates to sports.
"""

# -----------------------------------
# Streamlit Page Config
# -----------------------------------
st.set_page_config(
    page_title="AI Sports Rules Generator",
    page_icon="🏆",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling (Dark Glassmorphic UI)
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap');

html, body, [class*="css"] {
    font-family: 'Outfit', sans-serif;
}

/* Background styling */
.stApp {
    background: radial-gradient(circle at 10% 20%, rgba(20, 20, 35, 1) 0%, rgba(9, 9, 11, 1) 90.1%);
    color: #f4f4f5;
}

/* Main title header */
.main-title {
    font-weight: 800;
    font-size: 2.8rem;
    background: linear-gradient(135deg, #60a5fa, #c084fc);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 0.5rem;
    text-align: center;
}

.subtitle {
    font-size: 1.1rem;
    color: #a1a1aa;
    text-align: center;
    margin-bottom: 2.5rem;
}

/* Custom Cards */
.rule-card {
    background: rgba(30, 41, 59, 0.45);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 16px;
    padding: 1.5rem;
    margin-bottom: 1.2rem;
    transition: transform 0.2s, border-color 0.2s, box-shadow 0.2s;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.rule-card:hover {
    transform: translateY(-2px);
    border-color: rgba(96, 165, 250, 0.3);
    box-shadow: 0 10px 15px -3px rgba(96, 165, 250, 0.1), 0 4px 6px -2px rgba(96, 165, 250, 0.05);
}

.rule-sport {
    font-weight: 800;
    color: #c084fc;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 0.4rem;
}

.rule-title {
    font-weight: 600;
    color: #ffffff;
    font-size: 1.2rem;
    margin-bottom: 0.5rem;
}

.rule-desc {
    color: #cbd5e1;
    font-size: 0.95rem;
    line-height: 1.5;
}

/* Difficulty badges */
.badge {
    display: inline-block;
    padding: 0.15rem 0.6rem;
    border-radius: 999px;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-left: 0.5rem;
}
.badge-easy { background: rgba(34, 197, 94, 0.2); color: #4ade80; border: 1px solid rgba(74, 222, 128, 0.4); }
.badge-medium { background: rgba(234, 179, 8, 0.2); color: #facc15; border: 1px solid rgba(250, 204, 21, 0.4); }
.badge-hard { background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid rgba(248, 113, 113, 0.4); }

/* Sidebar styling */
[data-testid="stSidebar"] {
    background-color: #0c0a0f !important;
    border-right: 1px solid rgba(255, 255, 255, 0.05);
}

/* Button UI styling */
.stButton>button {
    background: linear-gradient(135deg, #3b82f6, #8b5cf6) !important;
    color: white !important;
    border: none !important;
    border-radius: 10px !important;
    padding: 0.5rem 1.5rem !important;
    font-weight: 600 !important;
    transition: opacity 0.2s !important;
}

.stButton>button:hover {
    opacity: 0.9 !important;
}

/* Chat bubble styling */
.user-msg {
    background: rgba(59, 130, 246, 0.15);
    border: 1px solid rgba(59, 130, 246, 0.3);
    border-radius: 12px;
    padding: 0.8rem 1.2rem;
    margin-bottom: 0.8rem;
}

.bot-msg {
    background: rgba(139, 92, 246, 0.15);
    border: 1px solid rgba(139, 92, 246, 0.3);
    border-radius: 12px;
    padding: 0.8rem 1.2rem;
    margin-bottom: 0.8rem;
}
</style>
""", unsafe_allow_html=True)

# -----------------------------------
# Static Sports & Rules Data
# -----------------------------------
sports_rules = {
    "cricket": {
        "lbw": "LBW (Leg Before Wicket): A batter is out if the ball hits the leg before the bat and would have gone on to hit the stumps.",
        "wide": "A wide ball is too far for the batter to reach in a normal batting position.",
        "no ball": "A no-ball is an illegal delivery. The batting team gets one extra run.",
        "free hit": "After most no-balls in limited-overs cricket, the next delivery is a free hit.",
        "powerplay": "Powerplay is a period with fielding restrictions.",
        "run out": "A batter is run out if the fielding team breaks the stumps before the batter reaches the crease.",
        "catch": "A batter is out if a fielder catches the ball before it touches the ground."
    },
    "football": {
        "offside": "A player is offside if they are nearer the opponent's goal line than both the ball and the second-last defender when the ball is played.",
        "penalty": "A penalty kick is awarded for certain fouls inside the penalty area.",
        "corner": "A corner kick is awarded when the defending team last touches the ball before it crosses the goal line.",
        "yellow card": "A yellow card is a warning given to a player.",
        "red card": "A red card means the player is sent off."
    },
    "basketball": {
        "travel": "Traveling happens when a player moves illegally while holding the ball.",
        "foul": "Illegal physical contact with an opponent.",
        "dribble": "A player must continuously bounce the ball while moving.",
        "three pointer": "A basket scored from beyond the three-point line is worth 3 points.",
        "free throw": "A free throw is an uncontested shot awarded after certain fouls."
    },
    "tennis": {
        "ace": "A legal serve that the opponent cannot return.",
        "deuce": "When both players reach 40 points.",
        "love": "Love means zero points.",
        "fault": "A serve that lands outside the correct service box.",
        "double fault": "Two consecutive faults result in losing the point."
    },
    "badminton": {
        "smash": "A powerful downward shot.",
        "let": "The rally is replayed.",
        "service": "The shuttle must be hit below the waist during service.",
        "fault": "An illegal action during play."
    },
    "volleyball": {
        "rotation": "Players rotate clockwise after winning the serve.",
        "block": "Stopping the opponent's attack near the net.",
        "ace": "A serve that lands untouched.",
        "libero": "A defensive specialist."
    },
    "kabaddi": {
        "raid": "The raider enters the opponent's court to score points.",
        "bonus": "A bonus point can be earned under specific conditions.",
        "super tackle": "When fewer than four defenders stop the raider.",
        "all out": "Occurs when all players of one team are out."
    },
    "hockey": {
        "penalty corner": "Awarded after certain fouls inside the shooting circle.",
        "penalty stroke": "A direct shot at goal after a serious foul.",
        "green card": "Temporary suspension.",
        "goal": "A goal counts only if scored from inside the shooting circle."
    }
}

glossary = {
    "ace": "A serve that wins the point immediately.",
    "lbw": "Leg Before Wicket.",
    "offside": "Illegal attacking position.",
    "dribble": "Moving while controlling the ball.",
    "raid": "Attacking move in Kabaddi.",
    "libero": "Defensive volleyball player.",
    "deuce": "40-40 in tennis.",
    "powerplay": "Fielding restrictions in cricket."
}

# -----------------------------------
# Quiz Question Bank (tagged with difficulty + sport)
# -----------------------------------
QUIZ_BANK = [
    # ---- Easy ----
    {
        "question": "Which rule belongs to Football?",
        "options": ["LBW", "Offside", "Deuce", "Raid"],
        "answer": "Offside",
        "difficulty": "Easy",
        "sport": "Football"
    },
    {
        "question": "What does LBW stand for?",
        "options": ["Leg Before Wicket", "Long Ball Wide", "Legal Bat Wicket", "Last Ball Win"],
        "answer": "Leg Before Wicket",
        "difficulty": "Easy",
        "sport": "Cricket"
    },
    {
        "question": "How many points is a three-pointer worth?",
        "options": ["1", "2", "3", "4"],
        "answer": "3",
        "difficulty": "Easy",
        "sport": "Basketball"
    },
    {
        "question": "Love means?",
        "options": ["10", "20", "30", "0"],
        "answer": "0",
        "difficulty": "Easy",
        "sport": "Tennis"
    },
    {
        "question": "In volleyball, how do players rotate after winning the serve?",
        "options": ["Clockwise", "Counter-clockwise", "Diagonally", "They don't rotate"],
        "answer": "Clockwise",
        "difficulty": "Easy",
        "sport": "Volleyball"
    },
    {
        "question": "What color card sends a football player off the field?",
        "options": ["Yellow", "Green", "Red", "Blue"],
        "answer": "Red",
        "difficulty": "Easy",
        "sport": "Football"
    },
    # ---- Medium ----
    {
        "question": "In cricket, what happens after a no-ball in limited-overs cricket?",
        "options": [
            "The batting team loses a wicket",
            "The next delivery is a free hit",
            "The innings ends",
            "The bowler is replaced"
        ],
        "answer": "The next delivery is a free hit",
        "difficulty": "Medium",
        "sport": "Cricket"
    },
    {
        "question": "In basketball, what is it called when a player moves illegally while holding the ball?",
        "options": ["Foul", "Traveling", "Double dribble", "Screening"],
        "answer": "Traveling",
        "difficulty": "Medium",
        "sport": "Basketball"
    },
    {
        "question": "In Kabaddi, what is a 'super tackle'?",
        "options": [
            "When the raider tags every defender",
            "When fewer than four defenders stop the raider",
            "When the raider crosses the baulk line",
            "When a defender is sent off"
        ],
        "answer": "When fewer than four defenders stop the raider",
        "difficulty": "Medium",
        "sport": "Kabaddi"
    },
    {
        "question": "In hockey, what is awarded after a serious foul inside the shooting circle, giving a direct shot at goal?",
        "options": ["Penalty corner", "Green card", "Penalty stroke", "Free hit"],
        "answer": "Penalty stroke",
        "difficulty": "Medium",
        "sport": "Hockey"
    },
    {
        "question": "In badminton, what is a 'let'?",
        "options": [
            "A point awarded automatically",
            "The rally is replayed",
            "A fault on serve",
            "A smash that lands out"
        ],
        "answer": "The rally is replayed",
        "difficulty": "Medium",
        "sport": "Badminton"
    },
    {
        "question": "In football, which team is awarded a corner kick?",
        "options": [
            "The attacking team, if the defender last touches the ball before it crosses the goal line",
            "The defending team, always",
            "Whichever team is losing",
            "The team that committed the last foul"
        ],
        "answer": "The attacking team, if the defender last touches the ball before it crosses the goal line",
        "difficulty": "Medium",
        "sport": "Football"
    },
    # ---- Hard ----
    {
        "question": "In cricket, a batter is given out LBW only if certain conditions are met. Which of these is NOT one of them?",
        "options": [
            "The ball would have gone on to hit the stumps",
            "The ball hits the leg before the bat",
            "The fielder catches the ball after it hits the pad",
            "The ball doesn't pitch outside leg stump"
        ],
        "answer": "The fielder catches the ball after it hits the pad",
        "difficulty": "Hard",
        "sport": "Cricket"
    },
    {
        "question": "In football, offside is judged relative to which two references at the moment the ball is played?",
        "options": [
            "The ball and the goalkeeper only",
            "The ball and the second-last defender",
            "The referee's position and the ball",
            "The center circle and the last defender"
        ],
        "answer": "The ball and the second-last defender",
        "difficulty": "Hard",
        "sport": "Football"
    },
    {
        "question": "In Kabaddi, what causes an 'all out'?",
        "options": [
            "One team scores 10 bonus points",
            "All players of one team are out",
            "The raid clock expires twice in a row",
            "A team fails to raid for 3 consecutive turns"
        ],
        "answer": "All players of one team are out",
        "difficulty": "Hard",
        "sport": "Kabaddi"
    },
    {
        "question": "In hockey, under what condition does a goal count?",
        "options": [
            "It's scored from anywhere inside the 25-yard line",
            "It's scored only from inside the shooting circle",
            "It's scored on a penalty corner only",
            "It's scored within the first quarter"
        ],
        "answer": "It's scored only from inside the shooting circle",
        "difficulty": "Hard",
        "sport": "Hockey"
    },
    {
        "question": "In tennis, what is the result of two consecutive faults on a serve?",
        "options": [
            "A let is called",
            "The server loses the point (double fault)",
            "The receiver serves next",
            "The point is replayed"
        ],
        "answer": "The server loses the point (double fault)",
        "difficulty": "Hard",
        "sport": "Tennis"
    },
]

DIFFICULTY_BADGE_CLASS = {
    "Easy": "badge-easy",
    "Medium": "badge-medium",
    "Hard": "badge-hard"
}

rule_day_options = [
    ("Football", "A red card sends a player off immediately."),
    ("Cricket", "A no-ball gives the batting team one extra run."),
    ("Basketball", "Traveling is illegal in basketball."),
    ("Tennis", "Deuce means both players have 40 points."),
    ("Volleyball", "A libero is a defensive specialist in volleyball.")
]

# Select a stable Rule of the Day based on the day
random.seed(42) # Keeping it simple and stable
rule_day_sport, rule_day_text = random.choice(rule_day_options)

# -----------------------------------
# Sidebar - Navigation & Settings
# -----------------------------------
with st.sidebar:
    st.image("https://img.icons8.com/color/96/trophy.png", width=70)
    st.markdown("### Navigation")
    page = st.radio(
        "Go to",
        ["🤖 AI Assistant", "📖 Rules Database", "🔤 Sports Glossary", "📝 Sports Quiz"]
    )
    
    st.markdown("---")
    st.markdown("### Settings")
    
    # Retrieve default key from environment
    default_api_key = os.getenv("GEMINI_API_KEY", "")
    
    user_api_key = st.text_input(
        "Gemini API Key",
        value=default_api_key,
        type="password",
        help="Paste your Gemini API Key here. If empty, the app will use the .env configuration."
    )
    
    st.markdown("---")
    st.markdown("💡 **Rule of the Day**")
    st.markdown(f"**{rule_day_sport}**: *{rule_day_text}*")

# Resolve API Key
api_key = user_api_key if user_api_key else default_api_key

# -----------------------------------
# Model Generation Function
# -----------------------------------
def generate_response(prompt: str) -> tuple[str, str]:
    """Generates response using the google.genai SDK with fallbacks and system prompt."""
    if not api_key:
        return "⚠️ Gemini API key not found. Please add a key in the sidebar or in the `.env` file to chat with the AI.", ""
    
    client = genai.Client(api_key=api_key)
    errors = []
    
    for model_name in CANDIDATE_MODELS:
        try:
            response = client.models.generate_content(
                model=model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    system_instruction=SYSTEM_INSTRUCTION,
                    temperature=0.3 # Lower temperature for more factual rules compliance
                )
            )
            if response and response.text:
                return response.text, model_name
        except Exception as e:
            errors.append(f"{model_name}: {e}")
            continue
            
    raise RuntimeError("All candidate models failed to generate content:\n" + "\n".join(errors))

# -----------------------------------
# Header UI
# -----------------------------------
st.markdown('<div class="main-title">🏆 AI Sports Rules Assistant</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">Your ultimate guide to sports rules, terminology, and interactive learning.</div>', unsafe_allow_html=True)

# -----------------------------------
# Page 1: AI Assistant
# -----------------------------------
if page == "🤖 AI Assistant":
    st.markdown("### 🤖 Ask the Sports Rules AI")
    st.write("Ask any questions about sports rules, game guidelines, or officiating. The AI is trained to ignore questions not related to sports rules.")
    
    # Display warning if API key is missing
    if not api_key:
        st.warning("⚠️ **Gemini API key is not configured.** Please enter your API key in the sidebar under Settings to activate the AI Chat.")
    else:
        # Chat interface
        for chat in st.session_state.chat_history:
            if chat["role"] == "user":
                st.markdown(f'<div class="user-msg"><b>You:</b><br>{chat["content"]}</div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="bot-msg"><b>AI ({chat["model"]}):</b><br>{chat["content"]}</div>', unsafe_allow_html=True)

        user_query = st.chat_input("Ask a sports rule (e.g. What is offside in football?)")

        if user_query:
            # Display user message instantly
            st.markdown(f'<div class="user-msg"><b>You:</b><br>{user_query}</div>', unsafe_allow_html=True)
            
            with st.spinner("Analyzing rule database..."):
                try:
                    answer, model_used = generate_response(user_query)
                    # Add to session history
                    st.session_state.chat_history.append({"role": "user", "content": user_query})
                    st.session_state.chat_history.append({"role": "assistant", "content": answer, "model": model_used})
                    
                    st.markdown(f'<div class="bot-msg"><b>AI ({model_used}):</b><br>{answer}</div>', unsafe_allow_html=True)
                except APIError as err:
                    st.error(f"API Error ({err.code}): {err.message}")
                except Exception as e:
                    st.error(f"An unexpected error occurred: {e}")

# -----------------------------------
# Page 2: Rules Database
# -----------------------------------
elif page == "📖 Rules Database":
    st.markdown("### 📖 Offline Rules Database")
    st.write("Browse rules for supported sports directly from our curated database. Use the search box to find specific terms.")
    
    search_query = st.text_input("🔍 Search Rules:", placeholder="Type a sport or rule keyword (e.g., LBW, offside)...").strip().lower()
    
    found_any = False
    
    for sport, rules in sports_rules.items():
        # Filter sport by search query
        matching_rules = {kw: desc for kw, desc in rules.items() if search_query in sport or search_query in kw or search_query in desc.lower()}
        
        if matching_rules:
            found_any = True
            with st.expander(f"🏅 {sport.title()}", expanded=(search_query != "")):
                for kw, desc in matching_rules.items():
                    st.markdown(f"""
                    <div class="rule-card">
                        <div class="rule-sport">{sport}</div>
                        <div class="rule-title">{kw.title()}</div>
                        <div class="rule-desc">{desc}</div>
                    </div>
                    """, unsafe_allow_html=True)
                    
    if not found_any:
        st.info("No matching rules found in the local database. Try searching for 'Cricket', 'LBW', 'offside', etc.")

# -----------------------------------
# Page 3: Sports Glossary
# -----------------------------------
elif page == "🔤 Sports Glossary":
    st.markdown("### 🔤 Sports Glossary")
    st.write("A quick reference guide for common sporting terms.")
    
    glossary_search = st.text_input("🔍 Search glossary term:", placeholder="Type a term to filter...").strip().lower()
    
    cols = st.columns(2)
    idx = 0
    for term, meaning in glossary.items():
        if glossary_search in term or glossary_search in meaning.lower():
            with cols[idx % 2]:
                st.markdown(f"""
                <div class="rule-card">
                    <div class="rule-title" style="color: #60a5fa;">{term.title()}</div>
                    <div class="rule-desc">{meaning}</div>
                </div>
                """, unsafe_allow_html=True)
                idx += 1
                
    if idx == 0:
        st.info("No glossary terms match your search.")

# -----------------------------------
# Page 4: Sports Quiz
# -----------------------------------
elif page == "📝 Sports Quiz":
    st.markdown("### 📝 Interactive Sports Quiz")
    st.write("Choose a difficulty level and how many questions you want, then test your knowledge!")

    # ---------- Quiz Setup ----------
    with st.container():
        st.markdown("#### ⚙️ Quiz Setup")
        setup_col1, setup_col2, setup_col3 = st.columns([1, 1, 1])

        with setup_col1:
            difficulty_choice = st.selectbox(
                "Difficulty Level",
                ["All Levels", "Easy", "Medium", "Hard"],
                key="difficulty_choice"
            )

        # How many questions are actually available for the chosen difficulty
        if difficulty_choice == "All Levels":
            available_pool = QUIZ_BANK
        else:
            available_pool = [q for q in QUIZ_BANK if q["difficulty"] == difficulty_choice]

        max_available = len(available_pool)

        with setup_col2:
            num_questions = st.number_input(
                "Number of Questions",
                min_value=1,
                max_value=max(max_available, 1),
                value=min(5, max_available) if max_available > 0 else 1,
                step=1,
                key="num_questions"
            )

        with setup_col3:
            st.markdown("<br>", unsafe_allow_html=True)
            start_clicked = st.button("🚀 Start / Restart Quiz")

        st.caption(f"Available questions at this difficulty: {max_available}")

        if start_clicked:
            if max_available == 0:
                st.warning("No questions available for this difficulty level.")
            else:
                n = min(num_questions, max_available)
                st.session_state.quiz_questions = random.sample(available_pool, n)
                st.session_state.quiz_answers = {}
                st.session_state.quiz_score = None
                st.session_state.quiz_started = True

    st.markdown("---")

    # ---------- Quiz Form ----------
    if not st.session_state.quiz_started or not st.session_state.quiz_questions:
        st.info("Set your difficulty and number of questions above, then click **Start / Restart Quiz**.")
    else:
        active_quiz = st.session_state.quiz_questions

        with st.form("quiz_form"):
            for i, q in enumerate(active_quiz):
                badge_class = DIFFICULTY_BADGE_CLASS.get(q["difficulty"], "badge-medium")
                st.markdown(
                    f'**Question {i+1}: {q["question"]}** '
                    f'<span class="badge {badge_class}">{q["difficulty"]}</span> '
                    f'<span class="badge" style="background:rgba(96,165,250,0.15); color:#60a5fa; border:1px solid rgba(96,165,250,0.4);">{q["sport"]}</span>',
                    unsafe_allow_html=True
                )

                # Retrieve previous choice if exists, default to index 0
                default_index = 0
                if i in st.session_state.quiz_answers and st.session_state.quiz_answers[i] in q["options"]:
                    default_index = q["options"].index(st.session_state.quiz_answers[i])

                choice = st.radio(
                    f"Select option for question {i+1}:",
                    options=q["options"],
                    index=default_index,
                    key=f"q_{i}",
                    label_visibility="collapsed"
                )
                st.session_state.quiz_answers[i] = choice
                st.markdown("<br>", unsafe_allow_html=True)

            submit_btn = st.form_submit_button("Submit Answers")

        if submit_btn:
            score = 0
            details = []
            for i, q in enumerate(active_quiz):
                user_ans = st.session_state.quiz_answers.get(i)
                is_correct = user_ans == q["answer"]
                if is_correct:
                    score += 1
                    details.append((q['question'], user_ans, q['answer'], "✅ Correct", q["difficulty"]))
                else:
                    details.append((q['question'], user_ans, q['answer'], f"❌ Incorrect (Correct: {q['answer']})", q["difficulty"]))

            st.session_state.quiz_score = score

            st.markdown(f"### 🎉 Quiz Finished! Your Score: **{score} / {len(active_quiz)}**")

            for q_title, user_a, correct_a, status, diff in details:
                badge_class = DIFFICULTY_BADGE_CLASS.get(diff, "badge-medium")
                with st.container():
                    st.markdown(
                        f"**Question:** {q_title} "
                        f'<span class="badge {badge_class}">{diff}</span>',
                        unsafe_allow_html=True
                    )
                    st.write(f"Your Answer: *{user_a}* | Status: **{status}**")
                    st.markdown("---")